\copy Loinc (loinc_num, component, property, time_aspct, system, scale_typ, method_typ, class, VersionLastChanged, chng_type, DefinitionDescription, status, consumer_name, classtype, formula, exmpl_answers, survey_quest_text, survey_quest_src, unitsrequired, submitted_units, relatednames2, shortname, order_obs, cdisc_common_tests, hl7_field_subfield_id, external_copyright_notice, example_units, long_common_name, UnitsAndRange, example_ucum_units, example_si_ucum_units, status_reason, status_text, change_reason_public, common_test_rank, common_order_rank, common_si_test_rank, hl7_attachment_structure, ExternalCopyrightLink, PanelType, AskAtOrderEntry, AssociatedObservations, VersionFirstReleased, ValidHL7AttachmentRequest, DisplayName ) FROM '../Loinc.csv' CSV HEADER

\copy MapTo (loinc, map_to, comment) FROM '../MapTo.csv' CSV HEADER


\copy SourceOrganization (id, copyright_id, name, copyright, terms_of_use, url) FROM '../SourceOrganization.csv' CSV HEADER

select count(*) from Loinc;
select count(*) from MapTo;
select count(*) from SourceOrganization;

